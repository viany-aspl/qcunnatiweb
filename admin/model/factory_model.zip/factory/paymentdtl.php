<?php
class ModelFactoryPaymentdtl extends Model {

        public function getAllUnits()
	{
		$query = $this->db->query('SELECT * FROM oc_unit ');
                return $query->rows;
		
	}
          public function getAllCompanys()
	{
		$query = $this->db->query('SELECT * FROM oc_company ');
                return $query->rows;
		
	}
        public function getunitbycompany($cid){
$sql="SELECT unit_id,unit_name from oc_unit WHERE company_id='".$cid."' ";
$query = $this->db->query($sql);

//echo $sql;
return $query->rows; 
}
        public function getStores()
	{
		$query = $this->db->query('SELECT store_id,name FROM oc_store');
		return $query->rows;
	}
    public function insrtPaymentdtl($data,$updated_by) 
        {
       
            $sql1="update  oc_unit set wallet_balance=wallet_balance +".$data["amount"]." where company_id='".$data['company']."' and unit_id='".$data['unit']."'";
            $query1 = $this->db->query($sql1);
            //exit;
            $query = $this->db->query("SELECT wallet_balance FROM oc_unit where company_id='".$data['company']."' and unit_id='".$data['unit']."'");
            $available_balance= $query->row['wallet_balance'];
        
        
            $sql="insert into  oc_unit_cash_trans set store_id='".$data["store"]."',user_id='".$updated_by."',amount='".$data['amount']."',transaction_type='".$data['transaction_type']."',payment_method='".$data['payment_method']."',unit_id='".$data['unit']."',tr_number='".$data['tr_number']."',company_id='".$data['company']."',available_balance='".$available_balance."',total_amount='".$data['amount']."',cr_db='CR' ";
            $query = $this->db->query($sql);
            $insert_id=$this->db->getLastId();

        }
        public function getPaymentList($data)
{
$sql='SELECT unit.unit_name,od.amount,od.transaction_type,DATE(od.create_date) as create_date,od.payment_method,user.firstname,user.lastname FROM `oc_unit_cash_trans` as od
LEFT JOIN oc_unit as unit on unit.unit_id=od.unit_id
LEFT JOIN oc_user as user on user.user_id=od.user_id';
if (!empty($data['filter_units_id'])) {
$sql .= " WHERE od.unit_id= '" . (int)$data['filter_units_id'] . "'";
} 
if (!empty($data['filter_date_start'])) {
$sql .= " AND DATE(od.create_date) >= '" . $this->db->escape($data['filter_date_start']) . "'";
}

if (!empty($data['filter_date_end'])) {
$sql .= " AND DATE(od.create_date) <= '" . $this->db->escape($data['filter_date_end']) . "'";
}

$sql.=" order by od.sid desc ";

if (isset($data['start']) || isset($data['limit'])) {
if ($data['start'] < 0) {
$data['start'] = 0;
}

if ($data['limit'] < 1) {
$data['limit'] = 20;
}

$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
}
//echo $sql;
$query= $this->db->query($sql);
return $query->rows;
}
public function getTotalPaymentList($data)
{
$sql='select count(*) as total from (SELECT unit.unit_name,od.amount,od.transaction_type,DATE(od.create_date) as create_date,od.payment_method,user.firstname,user.lastname FROM `oc_unit_cash_trans` as od
LEFT JOIN oc_unit as unit on unit.unit_id=od.unit_id
LEFT JOIN oc_user as user on user.user_id=od.user_id';
if (!empty($data['filter_units_id'])) {
$sql .= " WHERE od.unit_id= '" . (int)$data['filter_units_id'] . "'";
} 
if (!empty($data['filter_date_start'])) {
$sql .= " AND DATE(od.create_date) >= '" . $this->db->escape($data['filter_date_start']) . "'";
}

if (!empty($data['filter_date_end'])) {
$sql .= " AND DATE(od.create_date) <= '" . $this->db->escape($data['filter_date_end']) . "'";
}
$sql.=" ) as aa";
//echo $sql;
$query= $this->db->query($sql);
return $query->row['total'];
}
        
        
}
?>
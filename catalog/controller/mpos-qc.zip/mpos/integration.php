<?php
class GROWER{
    public $id;
    public $name;
    public $fname;
    public $village;
    public $status;
    public $message;
   
    }
class Controllermposintegration extends Controller{

    public function adminmodel($model) {      
      $admin_dir = DIR_SYSTEM;
      $admin_dir = str_replace('system/','admin/',$admin_dir);
      $file = $admin_dir . 'model/' . $model . '.php';      
      //$file  = DIR_APPLICATION . 'model/' . $model . '.php';
      $class = 'Model' . preg_replace('/[^a-zA-Z0-9]/', '', $model);
      
      if (file_exists($file)) {
         include_once($file);
         
         $this->registry->set('model_' . str_replace('/', '_', $model), new $class($this->registry));
      } else {
         trigger_error('Error: Could not load model ' . $model . '!');
         exit();               
      }
   }
function authentication()
{

		/*$mcrypt=new MCrypt();
		$data=array();
		$data['status']=$mcrypt->encrypt('0');		
		$data['mob']=$mcrypt->encrypt("9910077037");
		$data['tagged']=$mcrypt->encrypt("220");
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));*/
		
		$log=new Log("Authentication-grower-".date('Y-m-d').".log");
		$mcrypt=new MCrypt();
		$log->write($this->request->post);
		$log->write($this->request->get);
		$this->request->post["cdata"]=$mcrypt->decrypt($this->request->post["cdata"]);		
		$this->request->post["cdata"]=json_decode($this->request->post["cdata"]);		
		$log->write($this->request->post["cdata"]);
		$this->request->post["grower_id"]=$mcrypt->decrypt($this->request->post["cdata"]->GC);		
		$this->request->post["Card_Serial_Number"]=$mcrypt->decrypt($this->request->post["cdata"]->CSN);		
		$this->adminmodel('card/integration');	
		//get can server GetCardStatus
		$log->write("from cane server");
				  $this->request->post['CARD_SERIAL_NUMBER']= $this->request->post["Card_Serial_Number"];
				  $this->request->post['CARD_GROWER_ID']=  $this->request->post["grower_id"];
				  $this->request->post['CARD_UNIT']= $this->request->post["cdata"]->UN;
				  $this->adminmodel('unit/unit');
                 $unitdata= $this->model_unit_unit->getUnitByID($this->request->post["cdata"]->UN);
				 $datares="";
				 if(!empty($unitdata['company_name'])){
						$company=strtolower($unitdata['company_name']);
						$this->adminmodel('pos/'.$company);
						$datares = $this->{'model_pos_' . $company}->GetCardStatus('GetCardStatus',$this->request->post,0); 
						}
							//$this->load->library('soapcurl');
						//$soapcurl = new soapcurl($this->registry);
						//$datares= $soapcurl->GetCardStatus('GetCardStatus',$this->request->post,0); 
			$log->write($datares);						
		//get mobile number om card number or grower id
		$datamob=$this->model_card_integration->getmobileno($this->request->post);
		$log->write($datamob);		
		$data=array();
		if(!empty($datamob)){
		if($datamob['CARD_STATUS']=='9' && $datares=='9'){
		//send_otp
		if(!empty($datamob))
		{					
			$this->request->post["MOB"]=$datamob['MOB'];
			$this->request->post["TX"]="1";
			//check otp
			$dataAuthentication = $this->{'model_pos_' . $company}->GetAuthentication('GetAuthentication',$this->request->post,0);
			$log->write("tagged amount");
			$log->write($dataAuthentication);			
			$data['tagged']=$mcrypt->encrypt($dataAuthentication['AMOUNT']);			
			$dataotptrans=$this->model_card_integration->check_otp_trans($this->request->post);
			$log->write($dataotptrans);
		if(empty($dataotptrans) && (!empty($dataAuthentication['AMOUNT'])))
			{			 
			//get card authentication			
			$this->model_card_integration->send_otp($this->request->post);	
			$data['status']=$mcrypt->encrypt('1');
			}
			else{
				//send same otp $dataotptrans['otp']
				$data['status']=$mcrypt->encrypt('1');
			}
		}
		//$data['status']=$mcrypt->encrypt('1');
		}
		else{
		$data['status']=$mcrypt->encrypt('0');
		}
		$data['mob']=$mcrypt->encrypt($datamob['MOB']);
		}
		if(!empty($data)){
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));}
		
}

function growerdtl()
{
		$log=new Log("Card-Grower-dtl-".date('Y-m-d').".log");
		$mcrypt=new MCrypt();
		$log->write($this->request->post);
		$log->write($this->request->get);
		$this->request->post["cdata"]=$mcrypt->decrypt($this->request->post["cdata"]);		
		$this->request->post["cdata"]=json_decode($this->request->post["cdata"]);		
		$log->write($this->request->post["cdata"]);
		$this->request->post["grower_id"]=$mcrypt->decrypt($this->request->post["cdata"]->GC);		
		$this->request->post["Card_Serial_Number"]=$mcrypt->decrypt($this->request->post["cdata"]->CSN);		
		$this->adminmodel('card/integration');									
        $unitdata= $this->model_card_integration->getgrower($this->request->post["Card_Serial_Number"],$this->request->post["cdata"]->UN);
		$log->write($unitdata);
		$retdata=new GROWER();		
		$retdata->id  = $mcrypt->encrypt($unitdata['GROWER_ID']);
		$retdata->name      = $mcrypt->encrypt($unitdata['GROWER_NAME']);
		$retdata->fname       = $mcrypt->encrypt($unitdata['FTH_HUS_NAME']); 
		$retdata->village    = $mcrypt->encrypt($unitdata['VILLAGE_NAME']) ;
		$retdata->status	= $mcrypt->encrypt('1');
		$retdata->message	= $mcrypt->encrypt('Grower Details');					
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($retdata));			
}

function dispatch()
{

		$log=new Log("Card-Dispatch-".date('Y-m-d').".log");
		$retdata=array();
		$status="0";
        $message="Error";
		try{
		$mcrypt=new MCrypt();
		$log->write($this->request->post);
		$log->write($this->request->get);
		$this->request->post["cdata"]=$mcrypt->decrypt($this->request->post["cdata"]);		
		$this->request->post["cdata"]=json_decode($this->request->post["cdata"]);		
		$log->write($this->request->post["cdata"]);
		$this->request->post["grower_id"]=$mcrypt->decrypt($this->request->post["cdata"]->GC);		
		$this->request->post["Card_Serial_Number"]=$mcrypt->decrypt($this->request->post["cdata"]->CSN);		
		$this->adminmodel('card/integration');	
		
		$log->write("get unit");	
			$this->adminmodel('unit/unit');
                 $unitdata= $this->model_unit_unit->getUnitByID($this->request->post["cdata"]->UN);
				 $datares="";
				 $company="";
				 $log->write($unitdata);
				 if(!empty($unitdata['company_name'])){
						$company=strtolower($unitdata['company_name']);
						$this->adminmodel('pos/'.$company);
							$log->write("function unit");					
		//get status from cane server
		 $this->request->post['CARD_SERIAL_NUMBER']= $this->request->post["Card_Serial_Number"];
				  $this->request->post['CARD_GROWER_ID']=  $this->request->post["grower_id"];
				  $this->request->post['CARD_UNIT']= $this->request->post["cdata"]->UN;
		$canestatus= $this->{'model_pos_' . $company}->GetCardStatus('GetCardStatus',$this->request->post,0); 
		$log->write("after function");	
		
			$log->write($canestatus);	
			//get mobile number om card number or grower id
		$datamob=$this->model_card_integration->getmobileno($this->request->post);
		$log->write($datamob);
if(!empty($datamob)){		
		//update cane server
		if($datamob['CARD_STATUS']=='6'&& $canestatus=='6'){
		$this->request->post['CARD_STATUS']="7";
				   $this->request->post['CARD_STATUS_DESC']="CARD DISPATCHED";
				  $this->request->post['CARD_SERIAL_NUMBER']= $this->request->post["Card_Serial_Number"];
				  $this->request->post['CARD_GROWER_ID']=  $this->request->post["grower_id"];
				  $this->request->post['CARD_UNIT']= "0";
				  $this->request->post['CARD_QR_SRTING']="0";							
				$datares= $this->{'model_pos_' . $company}->CardStatus('CardStatus',$this->request->post,0); 
			$log->write($datares);
		if($datares=="1"){
		$isdispatched=$this->model_card_integration->card_dispatch($this->request->post);		
		if($isdispatched=="1")
		{
			$this->load->library('sms'); 
          $sms=new sms($this->registry);	  
		  //$sms->sendsms($datamob['MOB'], 17, $data);////////send otp 
		$status=$isdispatched;
                $message="Dispatched Success";
		}
		else
		{
			$status="0";
		$message="Dispatched Error";
		}
		$log->write($this->request->post);
		}
		else{
				$status="0";
		$message="Error in getting data from cane server.";
		}
		}
		else
		{
				$status="0";
				if($canestatus=="7")
				{
				$message="Card already dispatched.";
				}else{
		$message="Card status not matched with cane system.";
		}
		}
		
		}
		else
		{
		$status="0";
                                $message="Mobile number not found.";
		}
		}
		else
		{
		$status="0";
                                $message="Unknow card scaned";
		}
		}catch(Exception $e)
		{
			$status="0";
                                $message=$e->getMessage();
		}
		$retdata["status"]=$mcrypt->encrypt($status);
		$retdata["message"]=$mcrypt->encrypt($message);
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($retdata));
}

function senddelivery()
{
		$log=new Log("Card-Send-otp-".date('Y-m-d').".log");
		$mcrypt=new MCrypt();
		$retval=array();
		$status="0";
		$message="Error";
		$log->write($this->request->post);
		$log->write($this->request->get);
		$this->request->post["cdata"]=$mcrypt->decrypt($this->request->post["cdata"]);
		$log->write($this->request->post);
		$this->request->post["cdata"]=json_decode(($this->request->post["cdata"]));
		$this->request->post["grower_id"]=$mcrypt->decrypt($this->request->post["cdata"]->GC);
		$this->request->post["Card_Serial_Number"]=$mcrypt->decrypt($this->request->post["cdata"]->CSN);
		$this->adminmodel('card/integration');				
		$this->adminmodel('unit/unit');
        $unitdata= $this->model_unit_unit->getUnitByID($this->request->post["cdata"]->UN);
				 $log->write($unitdata);
				 $datares="";
				 $company="";
				 if(!empty($unitdata['company_name'])){
						$company=strtolower($unitdata['company_name']);
						$this->adminmodel('pos/'.$company);
					}		
		//get status from cane server
		 $this->request->post['CARD_SERIAL_NUMBER']= $this->request->post["Card_Serial_Number"];
				  $this->request->post['CARD_GROWER_ID']=  $this->request->post["grower_id"];
				  $this->request->post['CARD_UNIT']= $this->request->post["cdata"]->UN;
		$canestatus= $this->{'model_pos_' . $company}->GetCardStatus('GetCardStatus',$this->request->post,0); 
		$log->write($canestatus);
		if($canestatus=='7'){
		//get mobile number om card number or grower id
		$datamob=$this->model_card_integration->getmobileno($this->request->post);
		$log->write($datamob);
		if(!empty($datamob))
		{
		$this->request->post["MOB"]=$datamob['MOB'];
		$this->request->post["TX"]="2";
		$dataotptrans=$this->model_card_integration->check_otp_trans($this->request->post);
		$log->write($dataotptrans);
		if(empty($dataotptrans))
		{
			$this->request->post["OD"]="5";
			//send_otp
			$this->request->post["TX"]="2";
			$retdata=$this->model_card_integration->send_otp($this->request->post);				
				$status=$retdata;
				$message="Grower details";
			
		}
		else
		{
			$retdata="1";
			$status=$retdata;
			$message="OTP already sent.";
		}		

		//$otp = rand(10000, 99999);
		$log->write($retdata);		
		
		
		
		}
		else{
		
				$status="0";
				$message="Mobile number not found";
		}
		}
		else{
		
			$status="1";
			$message="Card not activated.";
		}
		$retval['status']=$mcrypt->encrypt($status);
		$retval['message']=$mcrypt->encrypt($message);
		$this->response->addHeader('Content-Type: application/json');		
		$this->response->setOutput(json_encode($retval));
}

function delivery()
{
		$log=new Log("Card-delivery-".date('Y-m-d').".log");
		$mcrypt=new MCrypt();
		$retval=array();
		//$log->write($this->request->server);
		$log->write($this->request->post);
		$log->write($this->request->get);
		$this->request->post["cdata"]=json_decode($mcrypt->decrypt($this->request->post["cdata"]));
		$this->request->post["grower_id"]=$mcrypt->decrypt($this->request->post["cdata"]->GC);
		$this->request->post["Card_Serial_Number"]=$mcrypt->decrypt($this->request->post["cdata"]->CSN);
		$this->request->post["otp"]=$mcrypt->decrypt($this->request->post["cin"]);
		$this->request->post['CARD_UNIT']= $this->request->post["cdata"]->UN;
		$this->request->post['TX']= "2";
		$this->adminmodel('card/integration');
		//$this->load->library('soapcurl');
		//$soapcurl = new soapcurl($this->registry);
		$this->adminmodel('unit/unit');
                 $unitdata= $this->model_unit_unit->getUnitByID($this->request->post["cdata"]->UN);
				 $datares="";
				 $company="";
				 if(!empty($unitdata['company_name'])){
						$company=strtolower($unitdata['company_name']);
						$this->adminmodel('pos/'.$company);
					}	
		$otpdata=	$this->model_card_integration->check_otp($this->request->post);
		$log->write($otpdata);
		if($otpdata['otp']==$this->request->post['otp']){
			$log->write("in if data");
		//get status from cane server
		 $this->request->post['CARD_SERIAL_NUMBER']= $this->request->post["Card_Serial_Number"];
				  $this->request->post['CARD_GROWER_ID']=  $this->request->post["grower_id"];
				  $this->request->post['CARD_UNIT']= $this->request->post["cdata"]->UN;
				  $log->write("in if data 1");
		$canestatus= $this->{'model_pos_' . $company}->GetCardStatus('GetCardStatus',$this->request->post,0); 
			$log->write($canestatus);	
		if($canestatus!='9'){
		//update to cane server
				  $this->request->post['CARD_STATUS']="9";
				  $this->request->post['CARD_STATUS_DESC']="CARD ACTIVATED";
				  $this->request->post['CARD_SERIAL_NUMBER']= $this->request->post["Card_Serial_Number"];
				  $this->request->post['CARD_GROWER_ID']=  $this->request->post["grower_id"];
				  //$this->request->post['CARD_UNIT']= "0";
				  $this->request->post['CARD_QR_SRTING']="0";
				  
						
						$datares= $this->{'model_pos_' . $company}->CardStatus('CardStatus',$this->request->post,0); 
			$log->write($datares);
		if($datares=="1"){
		$isdelivered=$this->model_card_integration->card_delivery($this->request->post);
		$log->write($this->request->post);
		//$this->response->addHeader('Content-Type: application/json');
		//$this->response->setOutput($isdelivered);}	
		
		$message="Success";
		$retval['status']=$mcrypt->encrypt($isdelivered);
		$retval['message']=$mcrypt->encrypt($message);
		
		
		}
		else
		{
		
		$message="Unable to connect cane system.";
		$retval['status']=$mcrypt->encrypt("0");
		$retval['message']=$mcrypt->encrypt($message);
		
		
		}
		}else
		{
		
		$message="Card status is not matched.";
		$retval['status']=$mcrypt->encrypt("0");
		$retval['message']=$mcrypt->encrypt($message);
		
		
		}
}
else
		{
		
		$message="OTP is not correct.";
		$retval['status']=$mcrypt->encrypt("0");
		$retval['message']=$mcrypt->encrypt($message);
		
		
		}
$this->response->addHeader('Content-Type: application/json');		
		$this->response->setOutput(json_encode($retval));
}
function getRequisition()
	{

		$log=new Log("Requisition-".date('Y-m-d').".log");
		$mcrypt=new MCrypt();
		$log->write($this->request->post);
		$log->write($this->request->get);

		$this->adminmodel('pos/pos');
		$log->write("model");
		$data=array();
		$data['storeid']=$mcrypt->decrypt($this->request->post["storeid"]);		
		$data['indentno']=$mcrypt->decrypt($this->request->post["indentno"]);
		$companydata=$this->model_pos_pos->getunitidandcompanyid($data); 
		if(!empty($companydata)){
		$data['unitid']=$companydata[0]['unit_id'];
		$log->write($companydata);
		$log->write($data);
		$company=strtolower($companydata[0]['company_name']);
		$log->write($company);
		$this->adminmodel('pos/'.$company);
		$results = $this->{'model_pos_' . $company}->getDataFromServer($data);
		$log->write($results);
				if(!empty($results)){
					
/*				
if (strpos($results, 'xml') !== false) {
					$this->response->addHeader('Content-Type: application/xhtml+xml');}
else{*/

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput($results);
		//error to display as per status
			
		}
		}else{		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput("{'error':'".$this->encryptRJ256('Company not defined')."'}");}
		
				
		}

function getRequisitiondtl()
	{

		$log=new Log("Requisitiondtl-".date('Y-m-d').".log");
		$mcrypt=new MCrypt();
		$log->write($this->request->post);
		$log->write($this->request->get);
		$this->adminmodel('pos/pos');
		$data=array();
		$data['storeid']=$mcrypt->decrypt($this->request->post["storeid"]);		
		$data['indentno']=$mcrypt->decrypt($this->request->post["indentno"]);
		$data['userid']=$mcrypt->decrypt($this->request->post["username"]);		
		$companydata=$this->model_pos_pos->getunitidandcompanyid($data); 
		$log->write($companydata);
		$log->write($data);
		$company=strtolower($companydata[0]['company_name']);
		$data['unitid']=$companydata[0]['unit_id'];
		$log->write($company);
		$this->adminmodel('pos/'.$company);
		$log->write("model");		
		$results = $this->{'model_pos_' . $company}->getDataDetailFromServer($data);//$this->model_pos_bcml->getDataFromServer($data);
		$log->write($results);
				if(!empty($results)){
					
/*				
if (strpos($results, 'xml') !== false) {
					$this->response->addHeader('Content-Type: application/xhtml+xml');}
else{*/

$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput($results);}
				
		}

function Updaterequisition()
	{

		$log=new Log("UpdateRequisition-".date('Y-m-d').".log");
		$mcrypt=new MCrypt();
		$log->write($this->request->post);
		$log->write($this->request->get);
		$this->adminmodel('pos/pos');
		$data=array();
		$data['storeid']=$mcrypt->decrypt($this->request->post["storeid"]);		
		$data['indentno']=$mcrypt->decrypt($this->request->post["oid"]);
		$data['userid']=$mcrypt->decrypt($this->request->post["username"]);
		$data['ordervalue']=$mcrypt->decrypt($this->request->post["invoicevalue"])-$mcrypt->decrypt($this->request->post["cash"]);
		$data['cash']=$mcrypt->decrypt($this->request->post["cash"]);
		$data['invoicevalue']=$mcrypt->decrypt($this->request->post["invoicevalue"]);
		$data['otp']=$mcrypt->decrypt($this->request->post["otp"]);
		$data['billno']=$mcrypt->decrypt($this->request->post["invoiceno"]);
		$companydata=$this->model_pos_pos->getunitidandcompanyid($data); 
		$log->write($companydata);
		$log->write($data);
		$company=strtolower($companydata[0]['company_name']);
		$data['unitid']=$companydata[0]['unit_id'];
		$log->write($company);
		$this->adminmodel('pos/'.$company);
		$log->write("model");		
		$results = $this->{'model_pos_' . $company}->setOrderDataToServer($data);
		$log->write($results);
				//if(!empty($results)){					
		//$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput((string)$results);
	//}		
	}

function encryptRJ256($encrypted)
{
			
     $iv = '!QAZ2WSX#EDC4RFV'; #Same as in C#.NET
     $key = '5TGB&YHN7UJM(IK<'; #Same as in C#.NET	
    //PHP strips "+" and replaces with " ", but we need "+" so add it back in...
    //$encrypted = str_replace(' ', '+', $encrypted);
    //get all the bits
$blockSize = mcrypt_get_block_size(MCRYPT_RIJNDAEL_128,MCRYPT_MODE_CBC);
$pad = $blockSize - (strlen($encrypted) % $blockSize);
    $rtn = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $encrypted.str_repeat(chr($pad), $pad), MCRYPT_MODE_CBC, $iv);
$rtn = base64_encode($rtn);
    return($rtn);
}

/*function test()
{
$this->adminmodel('pos/pos');
$products = $this->model_pos_pos->getProduct(80,8); 

print_r($products);
echo '<br/>';
print_r('tax_class_id-'.$products['tax_class_id']);
echo '<br/>';
echo 'tax-'.$this->tax->getTax($products['price'], $products['tax_class_id']);


}*/



}



?>